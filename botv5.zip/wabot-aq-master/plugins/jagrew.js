let fetch = require('node-fetch')

let handler = async (m, { conn, text }) => {
  if (!text) throw'Nomornya mana kak'
  let res = await fetch(global.API('xteam', '/spammer/jagreward?no='+text,'APIKEY'))
  if (res.status != true) throw'Silahkan masukan perintah yang valid'
 let result = await res.json()
 await conn.sendMessage(m.chat, result, {quoted: m})
}
handler.help = ['jag <nomor>']
handler.tags = ['Spammer']
handler.command = /^jag?$/i
handler.owner = true
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null

module.exports = handler