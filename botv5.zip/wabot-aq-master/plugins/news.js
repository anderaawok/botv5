let fetch = require('node-fetch')

let handler = async (m, { conn, text }) => {
  let res = await fetch(global.API('xteam', '/news/detik', 'APIKEY'))
 await conn.sendFile(m.chat, res.thumb, 'news.jpg', res.url + '\n\n' + res.judul + '\n' + res.artikel , m)
}
handler.help = ['news']
handler.tags = ['internet']
handler.command = /^news?$/i
handler.owner = true
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null

module.exports = handler